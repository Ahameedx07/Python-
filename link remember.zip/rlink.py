import asyncio
import logging
from datetime import datetime, timedelta
from telegram import Update, ChatPermissions
from telegram.ext import Application, CommandHandler, MessageHandler, ContextTypes
from telegram.ext import filters

# লগিং সেটআপ
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

# বট টোকেন
BOT_TOKEN = "8061273165:AAFbNWDTMciJOZ0YolsqQNJ_aJ0Fx8Hp6ug"

# অথরাইজড ইউজার আইডি (শুধুমাত্র আপনার আইডি)
AUTHORIZED_USER_ID = 5467795958

# ওয়ার্নিং স্টোরেজ
user_warnings = {}

def is_authorized(user_id):
    """চেক করে দেখুন ইউজার অথরাইজড কিনা"""
    return user_id == AUTHORIZED_USER_ID

async def delete_link_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """লিংক ডিটেক্ট করে মেসেজ ডিলিট করুন"""
    try:
        # শুধুমাত্র অথরাইজড ইউজারের জন্য এই ফিচার সক্রিয়
        user = update.message.from_user
        if not is_authorized(user.id):
            return
            
        message = update.message
        chat = update.message.chat
        
        # মেসেজ টেক্সট নিন
        text = message.text or message.caption or ""
        
        # এনটিটি থেকে টেক্সট নিন (টেলিগ্রামের লিংক ডিটেকশনের জন্য)
        entities = message.entities or message.caption_entities or []
        for entity in entities:
            if entity.type in ["url", "text_link"]:
                text = "http://dummy.com"  # লিংক আছে বলে ধরে নিন
                break
        
        # যদি কোনো লিংক থাকে
        if contains_link(text):
            try:
                # মেসেজ ডিলিট করুন
                await message.delete()
                logger.info(f"Message deleted - User: {user.id}, Chat: {chat.id}")
                
                # ইউজারকে ওয়ার্নিং দিন
                await send_warning(user, chat, context)
                
            except Exception as e:
                logger.error(f"Error deleting message: {e}")
                # ডিলিট করতে না পারলে অন্তত ওয়ার্নিং দিন
                try:
                    await send_warning(user, chat, context)
                except:
                    pass
    
    except Exception as e:
        logger.error(f"Error in delete_link_message: {e}")

def contains_link(text):
    """টেক্সটে লিংক আছে কিনা চেক করুন"""
    if not text:
        return False
    
    # সাধারণ লিংক প্যাটার্ন
    link_patterns = [
        "http://",
        "https://",
        "www.",
        ".com",
        ".org",
        ".net",
        ".bd",
        ".in",
        ".tk",
        ".ml",
        ".ga",
        ".cf",
        ".gq",
        ".xyz",
        "t.me/",
        "telegram.me/",
        "bit.ly/",
        "tinyurl.com/",
        "goo.gl/",
        "ow.ly/",
        "is.gd/",
        "buff.ly/",
        "adf.ly/",
        "bit.do/",
        "mcaf.ee/",
        "soo.gd/",
        "s2r.co/",
        "click.ru/",
        "smarturl.it/",
    ]
    
    text_lower = text.lower()
    for pattern in link_patterns:
        if pattern in text_lower:
            return True
    return False

async def send_warning(user, chat, context):
    """ইউজারকে ওয়ার্নিং মেসেজ পাঠান"""
    user_id = str(user.id)
    chat_id = str(chat.id)
    
    # ইউজার ওয়ার্নিং ট্র্যাক করুন
    key = f"{chat_id}_{user_id}"
    
    if key not in user_warnings:
        user_warnings[key] = {
            'count': 0,
            'last_warning': datetime.now(),
            'username': user.username or user.first_name
        }
    
    user_warnings[key]['count'] += 1
    user_warnings[key]['last_warning'] = datetime.now()
    warning_count = user_warnings[key]['count']
    
    # ওয়ার্নিং মেসেজ তৈরি করুন
    user_mention = user.mention_html() if user.username else f"<b>{user.first_name}</b>"
    
    warning_messages = [
        f"⚠️ {user_mention}, এই গ্রুপে লিংক শেয়ার করা নিষিদ্ধ!\n"
        f"📌 প্রথম সতর্কতা: আপনার লিংক সম্বলিত মেসেজ ডিলিট করা হয়েছে।",
        
        f"⚠️ {user_mention}, আপনি আবার লিংক শেয়ার করেছেন!\n"
        f"🚫 দ্বিতীয় সতর্কতা: পরবর্তী লিংক শেয়ার করলে আপনাকে মিউট করা হবে।",
        
        f"🚫 {user_mention}, আপনি বারবার লিংক শেয়ার করছেন!\n"
        f"⏳ আপনাকে ১ ঘন্টার জন্য মিউট করা হয়েছে।\n"
        f"🔢 সতর্কতা সংখ্যা: {warning_count} বার"
    ]
    
    # উপযুক্ত মেসেজ নির্বাচন করুন
    if warning_count >= 3:
        msg_index = 2
        # মিউট করুন (১ ঘন্টার জন্য)
        await mute_user(user, chat, context, hours=1)
    elif warning_count == 2:
        msg_index = 1
    else:
        msg_index = 0
    
    warning_msg = warning_messages[msg_index]
    
    try:
        # ওয়ার্নিং মেসেজ পাঠান (১০ সেকেন্ড পরে ডিলিট হবে)
        sent_message = await context.bot.send_message(
            chat_id=chat.id,
            text=warning_msg,
            parse_mode='HTML'
        )
        
        # ১০ সেকেন্ড পরে মেসেজ ডিলিট করুন
        await context.application.create_task(
            delete_after_delay(sent_message, 10)
        )
        
    except Exception as e:
        logger.error(f"Error sending warning: {e}")

async def mute_user(user, chat, context, hours=1):
    """ইউজারকে মিউট করুন"""
    try:
        until_date = datetime.now() + timedelta(hours=hours)
        
        await chat.restrict_member(
            user_id=user.id,
            permissions=ChatPermissions(
                can_send_messages=False,
                can_send_media_messages=False,
                can_send_other_messages=False,
                can_send_polls=False,
                can_add_web_page_previews=False,
                can_change_info=False,
                can_invite_users=False,
                can_pin_messages=False
            ),
            until_date=until_date
        )
        
        logger.info(f"User muted - User: {user.id}, Chat: {chat.id}, Hours: {hours}")
        
    except Exception as e:
        logger.error(f"Error muting user: {e}")

async def delete_after_delay(message, delay):
    """নির্দিষ্ট সময় পর মেসেজ ডিলিট করুন"""
    await asyncio.sleep(delay)
    try:
        await message.delete()
    except:
        pass

async def cleanup_old_warnings(context: ContextTypes.DEFAULT_TYPE):
    """পুরানো ওয়ার্নিং ডিলিট করুন (২৪ ঘন্টার বেশি)"""
    try:
        now = datetime.now()
        keys_to_remove = []
        
        for key, data in user_warnings.items():
            last_warning = data.get('last_warning')
            if last_warning and (now - last_warning).days >= 1:
                keys_to_remove.append(key)
        
        for key in keys_to_remove:
            del user_warnings[key]
            
        if keys_to_remove:
            logger.info(f"Cleaned up {len(keys_to_remove)} old warnings")
            
    except Exception as e:
        logger.error(f"Error in cleanup: {e}")

async def start_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """স্টার্ট কমান্ড হ্যান্ডলার"""
    user = update.message.from_user
    
    # শুধুমাত্র অথরাইজড ইউজার
    if not is_authorized(user.id):
        await update.message.reply_text("🚫 এই বট শুধুমাত্র মালিক ব্যবহার করতে পারবেন!")
        return
        
    await update.message.reply_text(
        "🤖 লিংক ডিটেকশন বট\n\n"
        "এই বটটি টেলিগ্রাম গ্রুপে সব ধরনের লিংক ডিটেক্ট করে ডিলিট করবে এবং "
        "ইউজারকে ওয়ার্নিং দেবে।\n\n"
        "গ্রুপে অ্যাডমিন হিসেবে যুক্ত করুন এবং 'Delete Messages' পারমিশন দিন।"
    )

async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """হেল্প কমান্ড হ্যান্ডলার"""
    user = update.message.from_user
    
    # শুধুমাত্র অথরাইজড ইউজার
    if not is_authorized(user.id):
        await update.message.reply_text("🚫 এই বট শুধুমাত্র মালিক ব্যবহার করতে পারবেন!")
        return
        
    await update.message.reply_text(
        "📖 সহায়িকা:\n\n"
        "1. বটকে গ্রুপে অ্যাডমিন করুন\n"
        "2. 'Delete Messages' পারমিশন দিন\n"
        "3. বট স্বয়ংক্রিয়ভাবে সব লিংক ডিটেক্ট ও ডিলিট করবে\n"
        "4. লিংক পাঠানো ইউজারকে ওয়ার্নিং দেওয়া হবে\n\n"
        "⚠️ নোট: গ্রুপ অ্যাডমিনরা লিংক শেয়ার করতে পারবেন।"
    )

async def stats_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """স্ট্যাটস কমান্ড (শুধু অ্যাডমিনদের জন্য)"""
    user = update.message.from_user
    chat = update.message.chat
    
    # শুধুমাত্র অথরাইজড ইউজার
    if not is_authorized(user.id):
        await update.message.reply_text("🚫 এই বট শুধুমাত্র মালিক ব্যবহার করতে পারবেন!")
        return
    
    total_warnings = sum(data['count'] for data in user_warnings.values())
    unique_users = len(user_warnings)
    
    stats_text = f"📊 বট স্ট্যাটিস্টিক্স:\n\n"
    stats_text += f"• মোট ওয়ার্নিং: {total_warnings}\n"
    stats_text += f"• অনন্য ইউজার: {unique_users}\n"
    stats_text += f"• স্টোরড ডাটা: {len(user_warnings)}\n\n"
    
    # ডিটেইলড স্ট্যাটস (যদি থাকে)
    if user_warnings:
        stats_text += "📝 ইউজার অনুযায়ী ওয়ার্নিং:\n"
        for key, data in list(user_warnings.items())[:10]:  # সর্বোচ্চ ১০ টা দেখাবে
            stats_text += f"  └ {data['username']}: {data['count']} বার\n"
    
    stats_text += f"\n🔄 সর্বশেষ আপডেট: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
    
    await update.message.reply_text(stats_text)

async def error_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """এরর হ্যান্ডলার"""
    logger.error(f"Update {update} caused error {context.error}")

def main():
    """মেইন ফাংশন"""
    # অ্যাপ্লিকেশন তৈরি করুন
    application = Application.builder().token(BOT_TOKEN).build()
    
    # কমান্ড হ্যান্ডলার
    application.add_handler(CommandHandler("start", start_command))
    application.add_handler(CommandHandler("help", help_command))
    application.add_handler(CommandHandler("stats", stats_command))
    
    # মেসেজ হ্যান্ডলার - সব ধরনের মেসেজ চেক করবে
    application.add_handler(MessageHandler(
        filters.TEXT | filters.CAPTION | filters.PHOTO | filters.Document.ALL,
        delete_link_message
    ))
    
    # জব কুইউ সেটআপ (পুরানো ওয়ার্নিং ক্লিনআপ)
    job_queue = application.job_queue
    if job_queue:
        job_queue.run_repeating(cleanup_old_warnings, interval=3600, first=10)
    
    # এরর হ্যান্ডলার
    application.add_error_handler(error_handler)
    
    # বট শুরু করুন
    logger.info("🤖 লিংক ডিটেকশন বট চালু হচ্ছে...")
    print("=" * 50)
    print("বট সফলভাবে চালু হয়েছে!")
    print(f"শুধুমাত্র আপনার আইডি ({AUTHORIZED_USER_ID}) থেকে ব্যবহারযোগ্য")
    print("গ্রুপে অ্যাডমিন হিসেবে যুক্ত করুন")
    print("বট টোকেন:", BOT_TOKEN)
    print("=" * 50)
    
    application.run_polling(allowed_updates=Update.ALL_TYPES)

if __name__ == '__main__':
    main()