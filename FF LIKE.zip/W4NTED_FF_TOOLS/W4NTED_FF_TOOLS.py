# ============================================================
#                    W4NTED FF TOOLS
#              হ্যাকিং জগতের কিং - Single File
# ============================================================
# Tool Name : W4NTED FF TOOLS
# Version   : 1.0
# Note      : All proto + menu + features in ONE Python file
#             account.json আলাদা রাখা হয়েছে
# ============================================================

import json
import os
import sys
import time
import google

# ============================================================
#                    PROTOBUF SECTION
# ============================================================

from google.protobuf import descriptor as _descriptor
from google.protobuf import descriptor_pool as _descriptor_pool
from google.protobuf import runtime_version as _runtime_version
from google.protobuf import symbol_database as _symbol_database
from google.protobuf.internal import builder as _builder

# ---------- freefire_pb2 ----------
_runtime_version.ValidateProtobufRuntimeVersion(
    _runtime_version.Domain.PUBLIC, 6, 30, 0, '', 'FreeFire.proto'
)
_sym_db = _symbol_database.Default()

DESCRIPTOR = _descriptor_pool.Default().AddSerializedFile(b'\n\x0e\x46reeFire.proto\"c\n\x08LoginReq\x12\x0f\n\x07open_id\x18\x16 \x01(\t\x12\x14\n\x0copen_id_type\x18\x17 \x01(\t\x12\x13\n\x0blogin_token\x18\x1d \x01(\t\x12\x1b\n\x13orign_platform_type\x18\x63 \x01(\t\"]\n\x10\x42lacklistInfoRes\x12\x1e\n\nban_reason\x18\x01 \x01(\x0e\x32\n.BanReason\x12\x17\n\x0f\x65xpire_duration\x18\x02 \x01(\r\x12\x10\n\x08\x62\x61n_time\x18\x03 \x01(\r\"f\n\x0eLoginQueueInfo\x12\r\n\x05\x61llow\x18\x01 \x01(\x08\x12\x16\n\x0equeue_position\x18\x02 \x01(\r\x12\x16\n\x0eneed_wait_secs\x18\x03 \x01(\r\x12\x15\n\rqueue_is_full\x18\x04 \x01(\x08\"\xa0\x03\n\x08LoginRes\x12\x12\n\naccount_id\x18\x01 \x01(\x04\x12\x13\n\x0block_region\x18\x02 \x01(\t\x12\x13\n\x0bnoti_region\x18\x03 \x01(\t\x12\x11\n\tip_region\x18\x04 \x01(\t\x12\x19\n\x11\x61gora_environment\x18\x05 \x01(\t\x12\x19\n\x11new_active_region\x18\x06 \x01(\t\x12\x19\n\x11recommend_regions\x18\x07 \x03(\t\x12\r\n\x05token\x18\x08 \x01(\t\x12\x0b\n\x03ttl\x18\t \x01(\r\x12\x12\n\nserver_url\x18\n \x01(\t\x12\x16\n\x0e\x65mulator_score\x18\x0b \x01(\r\x12$\n\tblacklist\x18\x0c \x01(\x0b\x32\x11.BlacklistInfoRes\x12#\n\nqueue_info\x18\r \x01(\x0b\x32\x0f.LoginQueueInfo\x12\x0e\n\x06tp_url\x18\x0e \x01(\t\x12\x15\n\rapp_server_id\x18\x0f \x01(\r\x12\x0f\n\x07\x61no_url\x18\x10 \x01(\t\x12\x0f\n\x07ip_city\x18\x11 \x01(\t\x12\x16\n\x0eip_subdivision\x18\x12 \x01(\t*\xa8\x01\n\tBanReason\x12\x16\n\x12\x42\x41N_REASON_UNKNOWN\x10\x00\x12\x1b\n\x17\x42\x41N_REASON_IN_GAME_AUTO\x10\x01\x12\x15\n\x11\x42\x41N_REASON_REFUND\x10\x02\x12\x15\n\x11\x42\x41N_REASON_OTHERS\x10\x03\x12\x16\n\x12\x42\x41N_REASON_SKINMOD\x10\x04\x12 \n\x1b\x42\x41N_REASON_IN_GAME_AUTO_NEW\x10\xf6\x07\x62\x06proto3')

_globals = globals()
_builder.BuildMessageAndEnumDescriptors(DESCRIPTOR, _globals)
_builder.BuildTopDescriptorsAndMessages(DESCRIPTOR, 'freefire_pb2', _globals)
if not _descriptor._USE_C_DESCRIPTORS:
    DESCRIPTOR._loaded_options = None
    _globals['_BANREASON']._serialized_start = 738
    _globals['_BANREASON']._serialized_end = 906
    _globals['_LOGINREQ']._serialized_start = 18
    _globals['_LOGINREQ']._serialized_end = 117
    _globals['_BLACKLISTINFORES']._serialized_start = 119
    _globals['_BLACKLISTINFORES']._serialized_end = 212
    _globals['_LOGINQUEUEINFO']._serialized_start = 214
    _globals['_LOGINQUEUEINFO']._serialized_end = 316
    _globals['_LOGINRES']._serialized_start = 319
    _globals['_LOGINRES']._serialized_end = 735

# ---------- send_like_pb2 ----------
_sym_db2 = _symbol_database.Default()
DESCRIPTOR2 = _descriptor_pool.Default().AddSerializedFile(b'\n\nlike.proto\"#\n\x04like\x12\x0b\n\x03uid\x18\x01 \x01(\x03\x12\x0e\n\x06region\x18\x02 \x01(\tb\x06proto3')

_globals2 = globals()
_builder.BuildMessageAndEnumDescriptors(DESCRIPTOR2, _globals2)
_builder.BuildTopDescriptorsAndMessages(DESCRIPTOR2, 'send_like_pb2', _globals2)
if _descriptor._USE_C_DESCRIPTORS == False:
    DESCRIPTOR2._options = None
    _globals2['_LIKE']._serialized_start = 14
    _globals2['_LIKE']._serialized_end = 49

# ============================================================
#                    TOOL CORE
# ============================================================

ACCOUNTS = []

def clear():
    os.system('cls' if os.name == 'nt' else 'clear')

def banner():
    clear()
    print("=" * 55)
    print("          ██╗    ██╗██╗  ██╗███╗   ██╗████████╗███████╗██████╗ ")
    print("          ██║    ██║██║  ██║████╗  ██║╚══██╔══╝██╔════╝██╔══██╗")
    print("          ██║ █╗ ██║███████║██╔██╗ ██║   ██║   █████╗  ██║  ██║")
    print("          ██║███╗██║██╔══██║██║╚██╗██║   ██║   ██╔══╝  ██║  ██║")
    print("          ╚███╔███╔╝██║  ██║██║ ╚████║   ██║   ███████╗██████╔╝")
    print("           ╚══╝╚══╝ ╚═╝  ╚═╝╚═╝  ╚═══╝   ╚═╝   ╚══════╝╚═════╝ ")
    print("=" * 55)
    print("                    W4NTED FF TOOLS v1.0")
    print("                  হ্যাকিং জগতের কিং")
    print("=" * 55)
    print()

def load_accounts():
    global ACCOUNTS
    if not os.path.exists("account.json"):
        print("[!] account.json পাওয়া যায়নি!")
        print("[!] একই ফোল্ডারে account.json রাখো")
        return False
    try:
        with open("account.json", "r", encoding="utf-8") as f:
            ACCOUNTS = json.load(f)
        print(f"[+] Successfully loaded {len(ACCOUNTS)} accounts")
        return True
    except Exception as e:
        print(f"[!] account.json লোড করতে সমস্যা: {e}")
        return False

def show_accounts():
    if not ACCOUNTS:
        print("[!] কোনো অ্যাকাউন্ট লোড হয়নি। আগে Option 1 দাও।")
        return
    print("\n" + "-" * 40)
    print(f"{'No.':<5} {'UID':<20} {'Password'}")
    print("-" * 40)
    for i, acc in enumerate(ACCOUNTS, 1):
        uid = acc.get("uid", "N/A")
        pwd = acc.get("password", "N/A")
        # hide full password
        masked = pwd[:3] + "****" if len(pwd) > 3 else "****"
        print(f"{i:<5} {uid:<20} {masked}")
    print("-" * 40)
    print(f"Total: {len(ACCOUNTS)} accounts\n")

def start_like():
    if not ACCOUNTS:
        print("[!] আগে অ্যাকাউন্ট লোড করো (Option 1)")
        return
    print("\n[+] Mass Like Mode")
    print(f"[+] Total accounts ready: {len(ACCOUNTS)}")
    target = input("[?] Target UID লিখো: ").strip()
    if not target:
        print("[!] Target UID খালি রাখা যাবে না")
        return
    region = input("[?] Region (BD/IND/SG etc) [BD]: ").strip() or "BD"
    print(f"\n[+] Target : {target}")
    print(f"[+] Region : {region}")
    print(f"[+] Accounts: {len(ACCOUNTS)}")
    confirm = input("\n[?] Start like process? (y/n): ").lower()
    if confirm != 'y':
        print("[!] Cancelled")
        return

    print("\n[+] Starting...")
    success = 0
    fail = 0
    for i, acc in enumerate(ACCOUNTS, 1):
        uid = acc.get("uid", "")
        print(f"[{i}/{len(ACCOUNTS)}] Using account {uid} ... ", end="")
        time.sleep(0.3)
        # Placeholder - real send like logic এখানে থাকবে
        # (user will add own implementation)
        print("OK (placeholder)")
        success += 1
    print("\n" + "=" * 40)
    print(f"[+] Finished")
    print(f"[+] Success : {success}")
    print(f"[+] Failed  : {fail}")
    print("=" * 40)

def check_accounts():
    if not ACCOUNTS:
        print("[!] আগে অ্যাকাউন্ট লোড করো (Option 1)")
        return
    print("\n[+] Checking accounts status...")
    for i, acc in enumerate(ACCOUNTS, 1):
        uid = acc.get("uid", "N/A")
        print(f"[{i}] {uid} → Live (placeholder check)")
        time.sleep(0.2)
    print("[+] Check complete\n")

def settings():
    print("\n" + "-" * 30)
    print("          SETTINGS")
    print("-" * 30)
    print("1. Reload account.json")
    print("2. Show current path")
    print("3. Back")
    choice = input("\nChoice: ").strip()
    if choice == "1":
        load_accounts()
    elif choice == "2":
        print(f"[+] Current directory: {os.getcwd()}")
    else:
        return

def main_menu():
    while True:
        banner()
        print("  [1] Load Accounts (account.json)")
        print("  [2] Show Loaded Accounts")
        print("  [3] Start Mass Like")
        print("  [4] Check Accounts Status")
        print("  [5] Settings")
        print("  [0] Exit")
        print()
        choice = input("  >>> Choice: ").strip()

        if choice == "1":
            load_accounts()
            input("\nPress Enter to continue...")
        elif choice == "2":
            show_accounts()
            input("\nPress Enter to continue...")
        elif choice == "3":
            start_like()
            input("\nPress Enter to continue...")
        elif choice == "4":
            check_accounts()
            input("\nPress Enter to continue...")
        elif choice == "5":
            settings()
            input("\nPress Enter to continue...")
        elif choice == "0":
            print("\n[+] W4NTED FF TOOLS থেকে বের হচ্ছি...")
            print("[+] Bye Bye!")
            sys.exit(0)
        else:
            print("[!] ভুল অপশন!")
            time.sleep(1)

if __name__ == "__main__":
    try:
        main_menu()
    except KeyboardInterrupt:
        print("\n\n[!] Stopped by user")
        sys.exit(0)
